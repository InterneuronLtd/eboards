﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="BedBoard.aspx.cs" Inherits="EBoards.BedBoard" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Bed Board</title>
    <link href="Content/bootstrap.css" rel="stylesheet" />    <link href="css/font-awesome.css" rel="stylesheet" />

    <style>
        html, body {
            height: 100% !important;
            margin: 0 !important;
            background-color: #fff;
        }

        #topSection {
            margin: 20px;
            padding: 20px;
            height: 30%;
        }

        #middleSection {
            margin: 20px;
            padding: 20px;
            height: 32%;
        }

        #bottomSection {
            margin: 20px;
            padding: 20px;
            height: 30%;
        }

        #detailSection {
            margin-left: 20px;
            margin-right: 20px;
            padding: 5px;
            height: 5%;
        }
    </style>

    <script src="Scripts/jquery-3.0.0.js"></script>

    <script>
        $(document).ready(function () {
             setInterval(function () {
                window.location.reload();
            }, 60000);
        })
    </script>
</head>
<body>

    
        <form id="form1" runat="server" style="height: 100%; background-color: #fff;">

            <div hidden="hidden">
                <asp:HiddenField ID="hdnBedBoardID" runat="server" />
                <asp:HiddenField ID="hdnWard" runat="server" />
                <asp:HiddenField ID="hdnBed" runat="server" />
            </div>

            <div id="topSection">
                <asp:Panel ID="pnlTopSingle" runat="server">
                    <div class="row" style="height: 100%;">
                        <div class="col-md-12" style="height: 100%;">
                            <asp:Literal ID="ltrlTop" runat="server"></asp:Literal>
                        </div>
                    </div>
                </asp:Panel>
                <asp:Panel ID="pnlTopDouble" runat="server">
                    <div class="row" style="height: 100%;">
                        <div class="col-md-6" style="height: 100%;">
                            <asp:Literal ID="ltrlTopLeft" runat="server"></asp:Literal>
                        </div>
                        <div class="col-md-6" style="height: 100%;">
                            <asp:Literal ID="ltrlTopRight" runat="server"></asp:Literal>
                        </div>
                    </div>
                </asp:Panel>
            </div>

            <div id="middleSection">
                <asp:Panel ID="pnlMiddleSingle" runat="server">
                    <div class="row" style="height: 100%;">
                        <div class="col-md-12" style="height: 100%;">
                            <asp:Literal ID="ltrlMiddle" runat="server"></asp:Literal>
                        </div>
                    </div>
                </asp:Panel>
                <asp:Panel ID="pnlMiddleDouble" runat="server">
                    <div class="row" style="height: 100%;">
                        <div class="col-md-6" style="height: 100%;">
                            <asp:Literal ID="ltrlMiddleLeft" runat="server"></asp:Literal>
                        </div>
                        <div class="col-md-6" style="height: 100%;">
                            <asp:Literal ID="ltrlMiddleRight" runat="server"></asp:Literal>
                        </div>
                    </div>
                </asp:Panel>
            </div>

            <div id="bottomSection">
                <asp:Panel ID="pnlBottomSingle" runat="server">
                    <div class="col-md-12">
                        <div class="row" style="height: 100%;">
                            <div class="col-md-12" style="height: 100%;">
                                <asp:Literal ID="ltrlBottom" runat="server"></asp:Literal>
                            </div>
                        </div>
                    </div>
                </asp:Panel>
                <asp:Panel ID="pnlBottomDouble" runat="server">
                    <div class="row" style="height: 100%;">
                        <div class="col-md-6" style="height: 100%;">
                            <asp:Literal ID="ltrlBottomLeft" runat="server"></asp:Literal>
                        </div>
                        <div class="col-md-6" style="height: 100%;">
                            <asp:Literal ID="ltrlBottomRight" runat="server"></asp:Literal>
                        </div>
                    </div>
                </asp:Panel>
            </div>

            <div id="detailSection">
                <div class="row" style="height: 100%;">
                    <div class="col-md-12" style="height: 100%;">
                        <asp:Literal ID="ltrlRefresh" runat="server"></asp:Literal>
                    </div>
                </div>
            </div>


        </form>
    
</body>
</html>
