﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="LoginOidc.aspx.cs" Inherits="EBoards.LoginOidc" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script src="globalsettings.js?v=1.0000010"></script>
    <script src="Scripts/oidc/oidc-client.js?v=1.0000010"></script>
    <script src="Scripts/oidc/OidcLoginHelper.js"></script>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            Please Wait...
        </div>
    </form>
</body>
</html>
