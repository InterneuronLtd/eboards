﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="SilentRenew.aspx.cs" Inherits="EBoards.SilentRenew" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script src="globalsettings.js?v=1.0000010"></script>
    <script src="Scripts/oidc/oidc-client.js?v=1.0000010"></script>
    <script src="Scripts/oidc/silent.js?v=1.0000010"></script>
</head>
<body>
    <form id="form1" runat="server">
        <div>
        </div>
    </form>
</body>
</html>
