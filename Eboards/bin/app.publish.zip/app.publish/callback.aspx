﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="callback.aspx.cs" Inherits="EBoards.callback" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title></title>
    <script src="Scripts/jquery-3.0.0.js"></script>
    <script src="GlobalSettings.js?v=1.0000010"></script>
    <script src="Scripts/oidc/oidc-client.js?v=1.0000010"></script>
    <script src="Scripts/oidc/callback.js?v=1.0000010"></script>
</head>
<body>
    <form id="form1" runat="server">
        <div>
            <asp:HiddenField ID="hTkn" runat="server" />
            Please wait...
            <div style="display: none">
                <asp:Button ID="btnPostback" runat="server" Text="" OnClick="btnPostback_Click" />
            </div>
            <div id="error"></div>
        </div>
    </form>
</body>
</html>
